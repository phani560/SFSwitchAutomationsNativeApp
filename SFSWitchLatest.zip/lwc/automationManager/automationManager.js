import { LightningElement, track } from 'lwc';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import setActivationAll from '@salesforce/apex/AutomationManagerController.setActivationAll';
import setActivationSingle from '@salesforce/apex/AutomationManagerController.setActivationSingle';
import fetchAllMetadataComponents from '@salesforce/apex/ToolingAPIServices.fetchAllMetadataComponents';

export default class AutomationManager extends LightningElement {
    // allRows holds the full dataset fetched once from server
    @track allRows = [];
    // rows is the filtered view
    @track rows = [];
    @track columns = [
        { label: 'Name', fieldName: 'name', type: 'text', sortable: true },
        { label: 'Type', fieldName: 'metadataType', type: 'text', sortable: true },
        {
            label: 'Active',
            fieldName: 'isActive',
            type: 'boolean',
            cellAttributes: { alignment: 'left' }
        },
        {
            type: 'button-icon',
            fixedWidth: 60,
            typeAttributes: {
                iconName: 'utility:power',
                title: 'Toggle',
                variant: 'bare',
                alternativeText: 'Toggle'
            }
        }
    ];

    @track typeOptions = [{ label: 'All', value: '' }];
    @track selectedType = '';
    @track searchText = '';
    @track isLoading = false;
    @track isMutating = false;
    @track istoggleLoading = false;
    // Per-row loading map: metadataId -> boolean
    @track rowLoading = {};
    // Batch progress state
    @track isBatchRunning = false;
    @track batchTotal = 0;
    @track batchProcessed = 0;
    @track batchPercent = 0;
    @track batchLabel = '';
    @track error;
    get errorMessage() {
        return this.error ? (this.error.body ? this.error.body.message : this.error.message || String(this.error)) : '';
    }

    // Overall counts derived from full dataset (allRows)
    get overallActive() {
        return (this.allRows || []).reduce((acc, r) => acc + (r.isActive === true ? 1 : 0), 0);
    }
    get overallInactive() {
        return (this.allRows || []).reduce((acc, r) => acc + (r.isActive === true ? 0 : 1), 0);
    }

    connectedCallback() {
        this.isLoading = true;
        this.loadData();
    }

    async loadData() {
        // Single server trip for the full dataset via ToolingAPIServices AuraEnabled fetchAllMetadataComponents
        // We reuse the existing controller: fetch entire list without server-side filters
        this.isLoading = true;
        this.error = undefined;
        try {
            // Static Apex import used; dynamic imports are not allowed in LWC
            const data = await fetchAllMetadataComponents();
            this.allRows = Array.isArray(data) ? data.map((r) => ({
                ...r,
                isActive: r.isActive === true
            })) : [];
            this.buildTypeOptionsFromData();
            this.applyClientFilters();
        } catch (e) {
            this.error = e;
        } finally {
            this.isLoading = false;
        }
    }

    buildTypeOptionsFromData() {
        // Build counts by type
        const counts = {};
        (this.allRows || []).forEach(r => {
            const t = r?.metadataType || '';
            if (!t) return;
            if (!counts[t]) {
                counts[t] = { active: 0, inactive: 0 };
            }
            if (r.isActive === true) {
                counts[t].active += 1;
            } else {
                counts[t].inactive += 1;
            }
        });

        // Compute total counts for "All"
        let totalActive = 0;
        let totalInactive = 0;
        Object.values(counts).forEach(c => {
            totalActive += c.active;
            totalInactive += c.inactive;
        });

        // Compose options with counts
        const options = [];
        options.push({
            label: `All (${totalActive} Active / ${totalInactive} Inactive)`,
            value: ''
        });

        Object.keys(counts)
            .sort()
            .forEach(t => {
                const c = counts[t];
                options.push({
                    label: `${t} (${c.active} Active / ${c.inactive} Inactive)`,
                    value: t
                });
            });

        this.typeOptions = options;

        // keep current selection if still valid; else reset to All
        if (this.selectedType && !counts[this.selectedType]) {
            this.selectedType = '';
        }
    }

    handleSearchChange(event) {
        this.searchText = (event && event.target && typeof event.target.value === 'string') ? event.target.value : '';
        // Normalize whitespace and trim to avoid mismatch
        this.searchText = this.searchText.normalize('NFKD').trim();
        this.applyClientFilters();
    }

    handleTypeChange(event) {
        this.selectedType = event.detail.value || '';
        this.applyClientFilters();
    }

    async handleEnableAll() {
        await this.runBatchActivation(true);
    }

    async handleDisableAll() {
        await this.runBatchActivation(false);
    }

    // Asynchronous batch processor: processes allRows in chunks of 50 by calling setActivationSingle
    async runBatchActivation(active) {
        // Guard if no data
        const all = Array.isArray(this.allRows) ? this.allRows : [];
        if (all.length === 0) {
            return;
        }

        // Build worklist based on desired active state and skip already-correct rows
        const worklist = all.filter(r => r?.metadataId && r?.metadataType)
                            .filter(r => r.isActive !== active);

        if (worklist.length === 0) {
            // Nothing to do
            this.dispatchEvent(new ShowToastEvent({
                title: 'Nothing to update',
                message: `All rows are already ${active ? 'Active' : 'Inactive'}.`,
                variant: 'info'
            }));
            return;
        }

        // Initialize progress UI
        this.isBatchRunning = true;
        this.isMutating = true;
        this.error = undefined;
        this.batchTotal = worklist.length;
        this.batchProcessed = 0;
        this.batchPercent = 0;
        this.batchLabel = `Starting...`;

        // Helper to update progress ring
        const updateProgress = () => {
            const pct = this.batchTotal ? Math.floor((this.batchProcessed / this.batchTotal) * 100) : 0;
            this.batchPercent = Math.min(100, Math.max(0, pct));
            this.batchLabel = `${this.batchProcessed}/${this.batchTotal}`;
        };

        // Chunk utility
        const chunkSize = 50;
        const chunks = [];
        for (let i = 0; i < worklist.length; i += chunkSize) {
            chunks.push(worklist.slice(i, i + chunkSize));
        }

        try {
            // Process chunks sequentially to avoid overwhelming the server, each chunk in parallel
            for (let c = 0; c < chunks.length; c += 1) {
                const chunk = chunks[c];

                // Prepare promises for the chunk (parallel within the chunk)
                const promises = chunk.map(row => {
                    const metadataId = row.metadataId;
                    const metadataType = row.metadataType;
                    // Skip rows missing identifiers
                    if (!metadataId || !metadataType) {
                        return Promise.resolve();
                    }
                    return setActivationSingle({ metadataId, metadataType, active })
                        .then(() => {
                            // Reflect UI state for the row locally
                            const setLocal = (arr) => {
                                const i = arr.findIndex(r => r.metadataId === metadataId);
                                if (i > -1) {
                                    arr[i] = { ...arr[i], isActive: active };
                                }
                            };
                            setLocal(this.allRows);
                            setLocal(this.rows);
                        })
                        .catch(err => {
                            // Collect but do not stop the whole batch; mark error on component
                            this.error = err;
                        })
                        .finally(() => {
                            this.batchProcessed += 1;
                            updateProgress();
                        });
                });

                // Wait for this chunk to complete
                await Promise.all(promises);

                // Yield back to event loop to keep UI responsive (micro-pause between chunks)
                // eslint-disable-next-line @lwc/lwc/no-async-operation
                await new Promise(resolve => requestAnimationFrame(() => resolve()));
            }

            // Finalize progress
            this.batchProcessed = this.batchTotal;
            updateProgress();
        } catch (e) {
            this.error = e;
        } finally {
            this.isBatchRunning = false;
            this.isMutating = false;
            // Recompute type options/counts and filtered view after local updates
            this.buildTypeOptionsFromData();
            this.applyClientFilters();
        }
    }

    // lightning-datatable onrowaction to handle toggle icon click
    // Support legacy datatable rowaction (kept for future use)
    async handleRowAction(event) {
        const row = event?.detail?.row;
        if (!row || !row.metadataId || !row.metadataType) return;
        await this.toggleSingle(row.metadataId, row.metadataType, !row.isActive);
    }

    // Handle lightning-input type="toggle" changes
    async handleToggleChange(event) {
        const metadataId = event.target?.dataset?.id;
        const metadataType = event.target?.dataset?.type;
        const next = event.target.checked === true;
        if (!metadataId || !metadataType) return;
        await this.toggleSingle(metadataId, metadataType, next);
    }

    // Shared toggle implementation for single-row updates
    async toggleSingle(metadataId, metadataType, next) {
        this.isMutating = true;
        this.error = undefined;
        this.istoggleLoading = true;
        // set row loading
        this.rowLoading = { ...this.rowLoading, [metadataId]: true };
        try {
            await setActivationSingle({ metadataId, metadataType, active: next });
            const upd = (arr) => {
                const i = arr.findIndex(r => r.metadataId === metadataId);
                if (i > -1) {
                    arr[i] = { ...arr[i], isActive: next, rowLoading: false };
                }
            };
            upd(this.allRows);
            upd(this.rows);
            this.dispatchEvent(new ShowToastEvent({
                title: 'Updated',
                message: `Row ${next ? 'enabled' : 'disabled'} successfully`,
                variant: 'success'
            }));
            this.istoggleLoading = false;
        } catch (e) {
            this.istoggleLoading = false;
            this.error = e;
            // revert UI if needed
            const revert = (arr) => {
                const i = arr.findIndex(r => r.metadataId === metadataId);
                if (i > -1) {
                    arr[i] = { ...arr[i], isActive: !next, rowLoading: false };
                }
            };
            revert(this.allRows);
            revert(this.rows);
            this.dispatchEvent(new ShowToastEvent({
                title: 'Update failed',
                message: this.errorMessage || 'Failed to update row',
                variant: 'error'
            }));
        } finally {
            // clear row loading map
            const { [metadataId]: _, ...rest } = this.rowLoading;
            this.rowLoading = { ...rest };
            // also ensure visible rows reflect no loading
            const clear = (arr) => {
                const i = arr.findIndex(r => r.metadataId === metadataId);
                if (i > -1) {
                    arr[i] = { ...arr[i], rowLoading: false };
                }
            };
            clear(this.rows);
            clear(this.allRows);
            this.isMutating = false;
        }
    }

    // Apply client-side filtering to allRows based on searchText and selectedType
    applyClientFilters() {
        // Prepare search tokens: split on whitespace to support multi-keyword search
        const raw = (this.searchText || '').normalize('NFKD').trim().toLowerCase();
        const tokens = raw ? raw.split(/\s+/).filter(Boolean) : [];
        const type = (this.selectedType || '').trim();

        // merge rowLoading flags into projection for template (avoid computed access)
        const withFlags = (this.allRows || []).map(r => ({
            ...r,
            rowLoading: this.rowLoading[r.metadataId] === true
        }));

        const filtered = withFlags.filter(r => {
            // Type filter (exact match when chosen)
            const typeOk = !type || (r.metadataType === type);

            // Build a normalized haystack across key fields
            const parts = [
                (r.name || ''),
                (r.metadataId || ''),
                (r.metadataType || '')
            ].join(' ').normalize('NFKD').toLowerCase();

            // Match strategy: ALL tokens must be present (AND)
            const searchOk = tokens.length === 0 || tokens.every(t => parts.includes(t));

            return typeOk && searchOk;
        });

        this.rows = [...filtered];
    }

    // Wire row action handler to datatable
    renderedCallback() {
        const table = this.template.querySelector('lightning-datatable');
        if (table && !this._rowHandlerInitialized) {
            table.addEventListener('rowaction', this.handleRowAction.bind(this));
            this._rowHandlerInitialized = true;
        }
    }
}